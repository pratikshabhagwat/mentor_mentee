<?php

namespace App\Controllers;

class Api extends BaseController
{
    public function testApi() {
        echo "<h1> whencome</h1>";      
    }
}